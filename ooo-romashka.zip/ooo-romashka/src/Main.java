public class Main {
    public static double totalBonusBudget(Employee[] staff) {
        double total = 0;
        for (Employee e : staff) {
            total += e.calculateBonus();
        }
        return total;
    }

    public static void main(String[] args) {
        Employee[] staff = new Employee[4];
        staff[0] = new Employee("Dima", "Разработчик", 90000);
        staff[1] = new Employee("Roma", "Аналитик", 80000);
        staff[2] = new Manager("Misha", "Руководитель отдела", 120000, 5);
        staff[3] = new Manager("Kiril", "Руководитель проекта", 150000, 8);

        System.out.println("Сотрудники и премии");
        for (Employee item : staff) {
            System.out.println(item);
            System.out.println(" Премия " + item.calculateBonus());
            System.out.println();
        }

        int managerCount = 0;
        System.out.println("Менеджеры");
        for (Employee item : staff) {
            if (item instanceof Manager) {
                Manager m = (Manager) item;
                managerCount++;
                System.out.println(m.getName() + " размер команды " + m.getTeamSize());
            }
        }
        System.out.println("Количество менеджеров " + managerCount);
        System.out.println();

        System.out.println("Создано сотрудников " + Employee.getEmployeeCount());
        System.out.println("Общий бюджет на премии " + totalBonusBudget(staff));
    }
}
